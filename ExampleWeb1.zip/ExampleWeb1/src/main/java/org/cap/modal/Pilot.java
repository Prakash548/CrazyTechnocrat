package org.cap.modal;


import java.util.Date;

import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class Pilot {

	private int PilotId;
	@NotEmpty(message="*Please Enter FirstName")
	private String FirstName;
	@NotEmpty(message="*Please Enter LastName")
	private String LastName;
	@Past(message="Enter valid Date")
	private Date DateOfBirth;
	private Date DateOfJoin;
	private Boolean isCertified;
	@Range(min=10000,max=150000,message="*Enter valid salary")
	private double Salary;
	
	public Pilot() {
		
	}

	public Pilot(int pilotId, String firstName, String lastName, Date dateOfBirth, Date dateOfJoin, Boolean isCertified,
			double salary) {
		super();
		PilotId = pilotId;
		FirstName = firstName;
		LastName = lastName;
		DateOfBirth = dateOfBirth;
		DateOfJoin = dateOfJoin;
		this.isCertified = isCertified;
		Salary = salary;
	}

	@Override
	public String toString() {
		return "Pilot [PilotId=" + PilotId + ", FirstName=" + FirstName + ", LastName=" + LastName + ", DateOfBirth="
				+ DateOfBirth + ", DateOfJoin=" + DateOfJoin + ", isCertified=" + isCertified + ", Salary=" + Salary
				+ "]";
	}

	public int getPilotId() {
		return PilotId;
	}

	public void setPilotId(int pilotId) {
		PilotId = pilotId;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public Date getDateOfBirth() {
		return DateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		DateOfBirth = dateOfBirth;
	}

	public Date getDateOfJoin() {
		return DateOfJoin;
	}

	public void setDateOfJoin(Date dateOfJoin) {
		DateOfJoin = dateOfJoin;
	}

	public Boolean getIsCertified() {
		return isCertified;
	}

	public void setIsCertified(Boolean isCertified) {
		this.isCertified = isCertified;
	}

	public double getSalary() {
		return Salary;
	}

	public void setSalary(double salary) {
		Salary = salary;
	}
	
	
}
