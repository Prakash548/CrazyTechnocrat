package org.cap.controller;

import org.cap.modal.Pilot;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@org.springframework.stereotype.Controller
public class Controller {

	@RequestMapping("/hii")
	public ModelAndView sayhii() {
		String message="Welcome! GoodMorning!";
		
		return new ModelAndView("hello","msg",message);
	}	
		@RequestMapping("/ValidateLogin")
		
		public String ValidateLogin(ModelMap map,
				@RequestParam("UserName")String UserName,
				@RequestParam("Password")String Password) {
		if(UserName.equals("Varun") && Password.equals("Varun123")){
			map.put("pilot", new Pilot());
					return "PilotForm";
		}
		return "redirect:/";
			
		}
		@PostMapping("/SavePilot")
		public String showPilotDetails(@ModelAttribute("pilot") Pilot pilot) {
			System.out.println(pilot);
			return "showPilot";
		}
	}