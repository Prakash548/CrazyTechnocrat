package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IProductDao;
import com.cg.model.HotelDetails;
@Service("pservice")
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	private IProductDao pdao;
	@Override
	public List<HotelDetails> getProducts() {
		
		return pdao.getProducts();
	}
	@Override
	public HotelDetails findProduct(String id) {

		return pdao.findProduct(id);
	}
	@Override
	public void updateProduct(HotelDetails product2) {
		
		 pdao.updateProduct(product2);
		
		
	}

}
