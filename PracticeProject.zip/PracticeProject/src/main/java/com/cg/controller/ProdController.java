package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.model.HotelDetails;
import com.cg.service.IProductService;
@Controller
public class ProdController {
	
	@Autowired
	private IProductService pservice;
	
	private HotelDetails productrec;
	
	@RequestMapping("/")
	public String showProduct(ModelMap map)
	{	
		List<HotelDetails> products=pservice.getProducts();
		map.put("p1", products);
		return "Product";
	}
	
	@RequestMapping("/update/{id}")
	public String Bookmyroom(ModelMap map,@PathVariable("id") int id)
	{
		if(id==1||id==2) {
			return "hiltonHotel";
		}
		else if(id==2) {
			return "vivantahotel";
		}
		else if(id==3) {
			return "newGinger";
		}
		return "something went wrong";
	}	
		
		/*productrec=pservice.findProduct(id);
		map.put("products", productrec);
	
		List<String> category=new ArrayList<>();
		category.add("Electronics");
		category.add("Home");
		category.add("Daily use");	
		
		map.put("categories", category);
		return "updateProduct";*/
	}
	
	/*	
	@PostMapping("/update/saveProduct")
	public String saveProduct(ModelMap map,@ModelAttribute("products") HotelDetails product2)
	{
		pservice.updateProduct(product2);
		return "redirect:/";
	}	
	*/