package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.HotelDetails;
@Repository("pdao")
@Transactional
public class ProductDaoImpl implements IProductDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public List<HotelDetails> getProducts() {
		List<HotelDetails> products =entityManager.createQuery("from HotelDetails").getResultList();
		return products;
	}
	
	@Override
	@Transactional
	public HotelDetails findProduct(String id) {
		
		HotelDetails productrec=entityManager.find(HotelDetails.class, id);
		return productrec;
	}
	
	@Transactional
	@Override
	public void updateProduct(HotelDetails product2) {
		entityManager.merge(product2);
		}

}
