package com.cg.productmgmt.ui;

import java.util.*;

import com.cg.productmgmt.bean.Product;
import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;


public class Client {
	IProductService productService=new ProductService();
	static Scanner scan=new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String option = null;
		//Scanner scan=new Scanner(System.in);
		Client c= new Client();
		while(true) {
			System.out.println("============Product Management==========");
			System.out.println("1:Update Product Price");
			System.out.println("2:Display all Product List");
			System.out.println("3: Exit");
			System.out.println("Choose an option:");
			option=scan.nextLine();
			switch(option) {
			case "1":
				c.updateProducts();
				break;
			case "2":
				c.displayProductList();
				break;
			case "3":
				System.exit(0);
				break;
			default:
					System.out.println("Invalid option");
					System.out.println();
					break;
			}
		}
		
	}
	public void displayProductList() {
		try {
			Map<String, Integer> productDetails= productService.getProductDetails();
			Set set=productDetails.entrySet();
			set.stream().forEach(System.out::println);
		}
		catch(ProductException ex) {
			System.out.println(ex.getMessage());
		}
		catch(Exception e) {
			System.err.println("An error Ocuured" +e.getMessage());
		}
	}
	private void updateProducts() {
		System.out.println("Enter Product category:");
		String category=scan.nextLine();
		System.out.println("Enter hikerate:");
		int hike=Integer.parseInt(scan.nextLine());
		Product product = new Product(category,hike);
		try{
			if(productService.validateUpdate(product)) {
				if(productService.updateProducts(category,hike)!=-1) {
					System.out.println("Product price has been successfully Updated..!!!");
				}
			}
			
		}
		catch(ProductException ex) {
			System.err.println("An error occured"+ex.getMessage());
		}
	}

}


















