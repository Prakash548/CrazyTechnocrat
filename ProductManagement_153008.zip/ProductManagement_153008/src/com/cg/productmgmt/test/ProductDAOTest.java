package com.cg.productmgmt.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.productmgmt.dao.IProductDAO;
import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;

public class ProductDAOTest {
	IProductDAO ps=new ProductDAO();
	@Before
	public void setUP() throws Exception{
	}
	@Test
	public void testUpdateProducts() throws ProductException{
		try {
			ps.updateProducts("toys",5);
		}
		catch(ProductException e) {
			throw new ProductException();
		}
	}
	@Test
	public void testGetProductDetails() throws ProductException{
			try {
				assertNotNull(ps.getProductDetails());
			}
			catch(ProductException e) {
				throw new ProductException();
			}
	}
}
