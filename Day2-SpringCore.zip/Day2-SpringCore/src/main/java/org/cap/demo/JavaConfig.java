package org.cap.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaConfig {

	
		@Bean
		public Employee getEmpbean() {
			Employee emp = new Employee();
			emp.setEmployeeId(1001);
			emp.setEmployeeName("Sarath");
			emp.setSalary(50000);
			emp.setAge(21);
			return emp;
			}
		
		@Bean
		public Address getAddbean() {
			Address address = new Address();
			address.setDoorNo("409");
			address.setStName("Alkapur TownShip");
			address.setCity("Hyderabad");
			return address;
		}
}
