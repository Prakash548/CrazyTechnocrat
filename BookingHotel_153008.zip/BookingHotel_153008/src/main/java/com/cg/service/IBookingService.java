package com.cg.service;

import java.util.List;

import com.cg.model.HotelDetails;
public interface IBookingService {

	public List<HotelDetails> getHotels();

	public HotelDetails findProduct(String id);
}
