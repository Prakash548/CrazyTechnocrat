package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IBookingDao;
import com.cg.model.HotelDetails;
@Service("pservice")
public class BookingServiceImpl implements IBookingService {
	
	@Autowired
	private IBookingDao pdao;
	public List<HotelDetails> getHotels() {
		
		return pdao.getHotels();
	}
	public HotelDetails findProduct(String id) {

		return pdao.findProduct(id);
	}

}
