package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.HotelDetails;
@Repository("pdao")
@Transactional
public class BookingDaoImpl implements IBookingDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	@Transactional
	public List<HotelDetails> getHotels() {
		List<HotelDetails> products =entityManager.createQuery("from HotelDetails").getResultList();
		return products;
	}
	
	@Override
	@Transactional
	public HotelDetails findProduct(String id) {
		
		HotelDetails productrec=entityManager.find(HotelDetails.class, id);
		return productrec;
	}


}
