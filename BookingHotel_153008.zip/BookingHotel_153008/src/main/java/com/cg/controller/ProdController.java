package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.model.HotelDetails;
import com.cg.service.IBookingService;
@Controller
public class ProdController {
	
	@Autowired
	private IBookingService pservice;
	
	private HotelDetails productrec;
	
	@RequestMapping("/")
	public String showProduct(ModelMap map)
	{	
		List<HotelDetails> products=pservice.getHotels();
		map.put("p1", products);
		return "Product";
	}	
	@RequestMapping("/update/{name}")
	public String Bookmyroom(ModelMap map,@PathVariable("name") String name)
	{
		String name1=name;
		map.put("name1",name1);
		return "BookingConfirmation";
	}
	}


