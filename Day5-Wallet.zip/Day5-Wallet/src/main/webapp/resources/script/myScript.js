function showButton(){
	if(document.getElementById('credit').checked){
		document.getElementById('btnType').value="Deposit";
	}else{
		document.getElementById('btnType').value="Withdraw";
	}
}
 

function ValidateForm(){
	 var uname=myform.username.value;
	 var pwd=myform.username.value;
	 var flag=false;
	 if(uname=="" || uname==null){
		 document.getElementById('userErrMsg').innerHTML=" * Please enter userName";
	 }
	 else
	 if(pwd=="" || pwd==null){
		 flag=false;
		 document.getElementById('userErrMsg').innerHTML=" ";
		 document.getElementById('pwdErrMsg').innerHTML=" * Please enter userName";
	 }
	 else{
		 flag=true;
		 document.getElementById('userErrMsg').innerHTML=" ";
		 document.getElementById('pwdErrMsg').innerHTML=" "
	 }
	return flag;
}



	function showYearDiv(){
		if(document.getElementById('rd').checked ||
				document.getElementById('fd').checked)
			document.getElementById('yearsDiv').style.display='block';
		else
			document.getElementById('yearsDiv').style.display='none';
	}




	window.onload= function(){
		document.getElementById('yearsDiv').style.display='none';
	} 
	 
