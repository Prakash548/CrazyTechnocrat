package org.cap.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface IAccountDao {
					
			public void createAccount(Account acc);
			public List<Account> getAllAccounts(int custId);
			public Map<Account, Double> getAmoutCrDe(String strQuery,int custId);
			public void addTransaction(Transaction trans1);
			public Account findAccount(long accountNo);
			public List<Transaction> getTransactions(Integer id);
			public void fundTransfer(Transaction transaction);
			public Account getAccount(long accNo);
			public Account getAccount1(long accNo1);
			public List<Account> getAllToAccounts(Integer customerId);
}
