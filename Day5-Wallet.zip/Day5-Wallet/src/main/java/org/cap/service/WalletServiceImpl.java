package org.cap.service;

import org.cap.dao.IWalletDao;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("walletService")
public class WalletServiceImpl implements IWalletService {
	
	@Autowired
	private IWalletDao walletDao;

	@Override
	public boolean validateLogin(int customerId, String custPwd) {
		// TODO Auto-generated method stub
		return walletDao.validateLogin(customerId, custPwd);
	}

	@Override
	public String getcustName(int customerId) {
		// TODO Auto-generated method stub
		return walletDao.getcustName(customerId);
	}

	@Override
	public Customer findCustomer(int custId) {
		// TODO Auto-generated method stub
		return walletDao.findCustomer(custId);
	}

}
